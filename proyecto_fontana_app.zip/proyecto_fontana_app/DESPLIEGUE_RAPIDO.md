# 🚀 Guía Rápida de Despliegue

## La Forma MÁS RÁPIDA (3 minutos)

### Opción 1: Netlify Drop (RECOMENDADO - Sin instalar nada)

1. Ve a: https://app.netlify.com/drop
2. Arrastra la carpeta `proyecto_fontana_app` completa
3. ¡Listo! Tu sitio estará online en 10 segundos
4. Te darán un link como: `https://nombre-random.netlify.app`

**Ventajas:**
- ✅ Cero configuración
- ✅ HTTPS automático
- ✅ Sin comandos
- ✅ Gratis

---

### Opción 2: Vercel (2 minutos)

1. Ve a: https://vercel.com/new
2. Registrate con GitHub/GitLab/Email
3. Arrastra la carpeta del proyecto
4. Clic en "Deploy"
5. ¡Listo!

**Ventajas:**
- ✅ Muy rápido
- ✅ Dominio gratis
- ✅ HTTPS automático

---

### Opción 3: Google Cloud Run (5 minutos)

**Requisito:** Tener instalado Google Cloud SDK

```bash
# 1. Autenticarse
gcloud auth login

# 2. Configurar proyecto
gcloud config set project TU-PROJECT-ID

# 3. Desplegar (desde la carpeta del proyecto)
cd proyecto_fontana_app
gcloud run deploy proyecto-fontana \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated

# 4. Listo! Te dará un link como:
# https://proyecto-fontana-xxxxx-uc.a.run.app
```

**Ventajas:**
- ✅ Infraestructura de Google
- ✅ Escalable
- ✅ Integración con otros servicios de GCP

**Desventajas:**
- ⚠️ Requiere tarjeta de crédito (pero tiene capa gratuita)
- ⚠️ Más complejo de configurar

---

### Opción 4: Firebase Hosting (3 minutos)

```bash
# 1. Instalar Firebase CLI
npm install -g firebase-tools

# 2. Login
firebase login

# 3. Inicializar (desde la carpeta del proyecto)
cd proyecto_fontana_app
firebase init hosting

# Cuando pregunte:
# - Public directory: . (punto)
# - Single-page app: Yes
# - GitHub deploys: No

# 4. Desplegar
firebase deploy

# Te dará un link como:
# https://tu-proyecto.web.app
```

**Ventajas:**
- ✅ Gratis
- ✅ CDN global
- ✅ HTTPS automático
- ✅ Fácil de actualizar

---

## 🔄 ¿Cómo actualizar después?

### Netlify Drop
Vuelve a arrastrar la carpeta. Reemplazará la versión anterior.

### Vercel
Desde el dashboard, sube los archivos nuevos o conecta con Git.

### Google Cloud Run
```bash
gcloud run deploy proyecto-fontana --source .
```

### Firebase
```bash
firebase deploy
```

---

## 🎯 Mi Recomendación Personal

Para este proyecto, te recomiendo **Netlify Drop** porque:

1. ✅ **Cero instalación** - No necesitas instalar nada
2. ✅ **30 segundos** - Es literalmente arrastrar y soltar
3. ✅ **Gratis** - No pide tarjeta de crédito
4. ✅ **Dominio HTTPS** - Te da un dominio seguro automáticamente
5. ✅ **Fácil de actualizar** - Volvés a arrastrar cuando quieras cambiar algo

---

## 🆘 Problemas Comunes

### "gcloud: command not found"
Necesitas instalar Google Cloud SDK: https://cloud.google.com/sdk/docs/install

### "firebase: command not found"
Necesitas instalar Node.js y luego: `npm install -g firebase-tools`

### No tengo tarjeta de crédito para Google Cloud
Usa **Netlify** o **Vercel** - son completamente gratis sin tarjeta.

### Quiero un dominio personalizado (ejemplo.com)
- **Netlify:** Settings → Domain Management → Add custom domain
- **Vercel:** Settings → Domains → Add
- **Google Cloud:** Cloud Run → Manage Custom Domains

---

## 📱 Probar Localmente Antes de Desplegar

```bash
# Con Python (ya viene instalado en Mac/Linux)
cd proyecto_fontana_app
python -m http.server 8080

# Con Node.js
npx http-server -p 8080

# Luego abre: http://localhost:8080
```

---

## ✅ Checklist Antes de Desplegar

- [ ] Probé la aplicación localmente
- [ ] Todos los archivos están en la carpeta
- [ ] Leí el README.md
- [ ] Decidí qué plataforma usar
- [ ] Tengo las credenciales necesarias (si aplica)

---

## 🎉 ¡Éxito!

Una vez desplegado:
1. Copia el link que te den
2. Compartilo con tu equipo
3. Comenzá a usarlo
4. Hacé backups exportando a CSV regularmente

**¡Buena suerte con el Proyecto Fontana!** 🚀