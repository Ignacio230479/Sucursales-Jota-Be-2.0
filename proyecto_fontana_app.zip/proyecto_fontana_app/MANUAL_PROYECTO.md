# MANUAL COMPLETO DEL PROYECTO SUCURSAL FONTANA

## INFORMACIÓN GENERAL DEL PROYECTO

**Proyecto:** Puesta en Marcha Sucursal Fontana  
**Ubicación:** Parcela 308 - Parque Industrial Fontana, Chaco  
**Superficie:** 5.805,00 m²  
**Jefe de Proyecto:** Juan Ignacio Cedrolla  
**Fecha de Inicio:** 28 de Noviembre de 2025  
**Fecha Objetivo de Habilitación:** 2 de Enero de 2026  
**Plazo Total:** 35 días calendario

---

## DATOS CATASTRALES DEL INMUEBLE

- **Nomenclatura:** Circunscripción II - Sección A - Chacra 48 - Parcela 308
- **Departamento:** San Fernando
- **Localidad:** Fontana, Provincia del Chaco
- **Superficie Total:** 5.805,00 m²
- **Frentes:** 
  - Pasaje Roldán: 85,00 m
  - Calle Brown: CD 215,00 m
- **Tipo:** Galpón industrial
- **Propietario del Inmueble:** Espumas Litoral Sociedad Anónima (Matrícula N° 37.938)

---

## DIAGNÓSTICO DEL ESTADO ACTUAL

### ASPECTOS POSITIVOS EXISTENTES

**Infraestructura Base:**
- Galpón con estructura metálica en buen estado
- Techo de chapa sin filtraciones mayores
- Racks industriales ya instalados
- Iluminación industrial básica funcionando
- Portón principal operativo
- Murete perimetral de ladrillo
- Pisos de hormigón alisado
- Altura considerable para operaciones logísticas

**Servicios Existentes:**
- Instalación eléctrica básica con tableros
- Sistema contra incendios básico (matafuegos, señalización)
- Boca de incendio con manguera
- Tanque de presión Kaeser
- Baño construido con inodoro y lavabo
- Área de office/cocina con mesada y pileta
- Cerco perimetral con tejido

### OBRAS Y MEJORAS NECESARIAS

#### URGENTES (Semana 1)
1. **Instalaciones Eléctricas** - Normalización completa, instalación para reefers
2. **Sanitarios** - Terminaciones y mejoras
3. **Oficina Administrativa** - Completar construcción modular

#### IMPORTANTES (Semana 2-3)
4. **Seguridad Contra Incendios** - Completar equipamiento
5. **Acondicionamiento General** - Limpieza, pintura, desmalezado
6. **Iluminación** - LED adicional, perimetral, emergencia

#### NECESARIAS (Semana 3-4)
7. **Climatización** - Ventilación y aire acondicionado
8. **Conectividad** - Red de datos e internet
9. **Seguridad Física** - Cámaras y alarmas

---

## PRESUPUESTO TOTAL ESTIMADO

| CATEGORÍA | MONTO ESTIMADO |
|-----------|----------------|
| Instalaciones Eléctricas | $1.530.000 |
| Equipamiento de Frío (Reefers) | $8.300.000 |
| Sanitarios y Áreas de Servicio | $700.000 |
| Oficina Administrativa | $5.130.000 |
| Equipamiento Operativo | $650.000 |
| Depósito de Herramientas e Insumos | $1.010.000 |
| Área de Lavado de Camiones | $510.000 |
| Pintura y Señalización | $630.000 |
| Seguridad e Higiene | $720.000 |
| Limpieza y Acondicionamiento | $260.000 |
| Seguridad Física | $1.310.000 |
| Comunicaciones y Conectividad | $233.000 |
| Cartelería e Identificación | $315.000 |
| Habilitaciones y Permisos | $200.000 |
| Seguros (anuales) | $550.000 |
| Recursos Humanos | $210.000 |
| Otros | $425.000 |
| Contingencias (10%) | $2.269.000 |
| **TOTAL INVERSIÓN** | **$24.952.000** |

---

## CRONOGRAMA DE TRABAJO

### SEMANA 1: 28 Nov - 4 Dic
**Enfoque:** Diagnóstico y arranque de obras críticas

**Lunes 28/11:**
- Reunión kick-off en sitio
- Recorrida y registro fotográfico
- Solicitud de cotizaciones
- Definición de presupuesto

**Martes 29/11:**
- Inicio trabajos eléctricos
- Solicitud de habilitaciones municipales
- Publicación búsquedas laborales
- Pedido de equipamiento

**Resto de la semana:**
- Continuación obras eléctricas
- Inicio trabajos sanitarios
- Limpieza general
- Desmalezado
- Entrevistas laborales

### SEMANA 2: 5-11 Dic
**Enfoque:** Terminaciones básicas y servicios
- Finalización obras eléctricas
- Completar sanitarios
- Terminaciones de oficina
- Instalación A/A
- Alta de servicios
- Selección de personal

### SEMANA 3: 12-18 Dic
**Enfoque:** Seguridad y sistemas
- Sistema contra incendios
- Red de datos
- Cámaras de seguridad
- Señalización
- Pintura general
- Contratación personal
- Tramitación habilitaciones

### SEMANA 4: 19-25 Dic
**Enfoque:** Equipamiento y puesta a punto
- Instalación equipamiento
- Montaje mobiliario
- Pruebas de sistemas
- Capacitación inicial
- Carga de stock
- Inspecciones finales

### SEMANA 5: 26 Dic - 1 Ene
**Enfoque:** Ajustes finales y arranque
- Ajustes finales
- Simulacros operativos
- Capacitación final
- Verificación habilitaciones

**🎯 2 de Enero 2026: PUESTA EN MARCHA**

---

## ACTIVIDADES DETALLADAS

### 1. INSTALACIONES ELÉCTRICAS

#### 1.1 Normalización de Tableros
- **Costo:** $300.000
- **Plazo:** 29/11 - 06/12
- **Prioridad:** URGENTE
- **Observaciones:** Requiere electricista matriculado

#### 1.2 Instalación para Reefers
- **Costo:** $800.000
- **Plazo:** 02/12 - 13/12
- **Prioridad:** URGENTE
- **Observaciones:** Potencia trifásica especial

### 2. EQUIPAMIENTO DE FRÍO

#### 2.1 Contenedores Reefer
- **Cantidad:** 2 unidades
- **Costo:** $8.000.000
- **Plazo:** 28/11 - 20/12
- **Prioridad:** ALTA
- **Observaciones:** Coordinar entrega e instalación

### 3. MOBILIARIO Y EQUIPAMIENTO

#### 3.1 Mobiliario de Oficina
- **Cantidad:** 8 puestos completos
- **Costo:** $1.600.000
- **Incluye:** Escritorios, sillas, archivadores

#### 3.2 Computadoras
- **Cantidad:** 8 unidades
- **Costo:** $2.400.000
- **Observaciones:** Definir specs según necesidad

#### 3.3 Zorras Hidráulicas
- **Cantidad:** Mínimo 3 unidades
- **Costo:** $450.000
- **Capacidad:** 2500 kg c/u

#### 3.4 Hidrolavadora Industrial
- **Costo:** $280.000
- **Uso:** Para área de lavado de camiones

### 4. CONSTRUCCIONES Y OBRAS

#### 4.1 Depósito de Herramientas
- **Costo:** $350.000
- **Características:** Cerrado con puerta con llave
- **Para guardar:** Herramientas, artículos limpieza, hidrolavadora, aspiradora

#### 4.2 Área de Lavado de Camiones
- **Costo:** $320.000
- **Incluye:** Piso con pendiente, desagüe, conexión agua con presión
- **Adicional:** Mangueras y accesorios ($40.000)

#### 4.3 Pintado de Pasillos
- **Costo:** $180.000
- **Tipo:** Demarcación amarilla según normas de seguridad

### 5. SEGURIDAD E HIGIENE

#### 5.1 Plano de Evacuación
- **Costo:** $180.000
- **Proveedor:** Empresa de Higiene y Seguridad
- **Plazo:** 28/11 - 10/12
- **Observaciones:** Requerido para habilitación de Bomberos

#### 5.2 Sistema Contra Incendios
- **Matafuegos:** Mínimo 3 adicionales 10kg ABC
- **Recarga:** De matafuegos existentes
- **Luces emergencia**
- **Señalización**
- **Costo Total:** $310.000

### 6. COMUNICACIONES

#### 6.1 Internet Empresarial
- **Costo:** $45.000/mes
- **Características:** Mínimo 100 Mbps simétricos
- **Proveedores a consultar:** Telecom, Claro, Personal

#### 6.2 Cartel Exterior
- **Costo:** $220.000
- **Incluye:** Logo corporativo, iluminación
- **Ubicación:** Frente del galpón

---

## HABILITACIONES Y PERMISOS NECESARIOS

### MUNICIPALIDAD DE FONTANA

**Documentación a Presentar:**
- Contrato de alquiler
- Plano municipal aprobado
- Certificado de uso conforme
- Memoria descriptiva de la actividad
- Comprobante de pago de tasas
- CUIT de la empresa
- Estatuto social
- Poder del representante legal

**Habilitaciones:**
1. Habilitación comercial/industrial
2. Habilitación de bomberos
3. Inspección de seguridad e higiene
4. Certificado de aptitud ambiental (si corresponde)

### PROVINCIA DEL CHACO

1. Inscripción en Ingresos Brutos
2. Alta de establecimiento
3. Habilitación industrial (si corresponde)

### SERVICIOS PÚBLICOS

**SECHEEP (Electricidad):**
- Solicitud de suministro
- Contratación de potencia necesaria
- Instalación de medidor

**SAMEEP (Agua):**
- Alta del servicio
- Verificación de conexión

### SEGUROS NECESARIOS

1. Seguro de incendio
2. Seguro de responsabilidad civil
3. Seguro de contenido
4. ART para personal

---

## RECURSOS HUMANOS

### ESTRUCTURA DE PERSONAL (Ajustar según necesidad)

**Gerencia/Supervisión:**
- Gerente de sucursal
- Supervisor de operaciones

**Área Operativa:**
- Operarios (cantidad según volumen)
- Chofer de autoelevador
- Encargado de depósito

**Área Administrativa:**
- Administrativo/a
- Vendedor/a (si corresponde)

**Servicios:**
- Personal de limpieza
- Seguridad (propio o tercerizado)

### PROCESO DE SELECCIÓN

**Semana 1-2:**
- Publicación de búsquedas
- Recepción de CVs
- Preselección

**Semana 2-3:**
- Entrevistas iniciales
- Evaluaciones técnicas
- Verificación de referencias

**Semana 3:**
- Selección final
- Ofertas laborales
- Documentación para legajo

### DOCUMENTACIÓN LABORAL

Por cada empleado:
- Alta temprana en AFIP
- Contrato de trabajo
- Ficha de personal completa
- Fotocopia de DNI
- Certificado de estudios
- Examen preocupacional
- Alta en ART
- Declaración jurada de cargas de familia
- CBU para pagos

### PROGRAMA DE INDUCCIÓN

**Duración:** 3-5 días

**Contenidos:**
- Presentación de la empresa y valores
- Políticas y procedimientos internos
- Seguridad e higiene
- Uso de equipos y maquinaria
- Sistemas informáticos
- Productos/servicios
- Recorrida por instalaciones

---

## CONTACTOS IMPORTANTES

### AUTORIDADES LOCALES
- **Municipalidad de Fontana:** [Completar teléfono]
- **Bomberos Fontana:** [Completar teléfono]
- **ATIP Chaco:** [Completar teléfono]

### SERVICIOS PÚBLICOS
- **SECHEEP:** [Completar teléfono]
- **SAMEEP:** [Completar teléfono]

### PROVEEDORES A CONTACTAR
- **Electricista Matriculado:** [A definir]
- **Empresa de Higiene y Seguridad:** [A definir]
- **Proveedor de Reefers:** [A definir]
- **Internet Empresarial:** [A definir]

---

## INDICADORES DE SEGUIMIENTO

### KPIs DEL PROYECTO

1. **Avance de Obra:** % de actividades completadas
2. **Cumplimiento de Cronograma:** Días de adelanto/atraso
3. **Presupuesto:** Costo real vs. presupuestado
4. **Habilitaciones:** Cantidad de permisos obtenidos
5. **Personal:** Cantidad de posiciones cubiertas

### REUNIONES DE SEGUIMIENTO

**Frecuencia:** Semanal (todos los lunes)  
**Participantes:** Jefe de proyecto + responsables de área  
**Duración:** 1 hora  
**Agenda:**
- Revisión de avances
- Problemas y soluciones
- Planificación de la semana
- Actualización de presupuesto

---

## RIESGOS IDENTIFICADOS

| RIESGO | PROBABILIDAD | IMPACTO | MITIGACIÓN |
|--------|--------------|---------|------------|
| Demora en habilitaciones | Media | Alto | Iniciar trámites lo antes posible |
| Retraso en entrega de reefers | Media | Alto | Hacer pedido con anticipación |
| Falta de personal calificado | Media | Medio | Búsquedas amplias y atractivas |
| Sobrecostos en obras | Baja | Alto | Solicitar múltiples cotizaciones |
| Problemas eléctricos | Media | Alto | Contratar matriculado experimentado |

---

## CRITERIOS DE ÉXITO

El proyecto se considerará exitoso si:

1. ✅ La sucursal abre el 2 de enero de 2026
2. ✅ Todas las habilitaciones están aprobadas
3. ✅ El presupuesto no se excede en más del 10%
4. ✅ No hay accidentes de trabajo
5. ✅ El personal está contratado y capacitado
6. ✅ Todos los sistemas funcionan correctamente

---

## ANEXOS

- Anexo A: Plano catastral de la parcela 308
- Anexo B: Fotografías del relevamiento inicial
- Anexo C: Cotizaciones de proveedores
- Anexo D: Cronograma Gantt detallado
- Anexo E: Presupuesto detallado por rubro

---

**Documento elaborado por:** Juan Ignacio Cedrolla  
**Fecha:** 28 de Noviembre de 2025  
**Versión:** 1.0

---

**FIN DEL MANUAL**