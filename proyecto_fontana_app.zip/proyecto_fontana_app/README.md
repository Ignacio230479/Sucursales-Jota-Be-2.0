# Proyecto Sucursal Fontana - Sistema de Gestión

## 📋 Descripción
Sistema web interactivo para gestionar y dar seguimiento al proyecto de habilitación de la Sucursal Fontana.

**Jefe de Proyecto:** Juan Ignacio Cedrolla  
**Fecha de Inicio:** 28 de Noviembre de 2025  
**Fecha Objetivo:** 2 de Enero de 2026  

---

## 🚀 Instalación Rápida

### Opción 1: Abrir directamente en el navegador
1. Descomprimir el archivo ZIP
2. Hacer doble clic en `index.html`
3. ¡Listo! La aplicación se abrirá en tu navegador

### Opción 2: Servidor local (recomendado para desarrollo)
Si querés ejecutar con un servidor local:

```bash
# Si tenés Python instalado:
python -m http.server 8000

# Si tenés Node.js instalado:
npx http-server

# Luego abrir en el navegador:
http://localhost:8000
```

---

## 🌐 Despliegue en Google Cloud (Antigravity)

### Requisitos Previos
- Cuenta de Google Cloud
- Proyecto creado en Google Cloud Console
- Google Cloud SDK instalado (gcloud CLI)

### Paso 1: Instalar Google Cloud SDK
Si no tenés instalado el SDK de Google Cloud:

**Windows:**
```bash
# Descargar desde: https://cloud.google.com/sdk/docs/install
```

**Mac/Linux:**
```bash
curl https://sdk.cloud.google.com | bash
exec -l $SHELL
gcloud init
```

### Paso 2: Configurar el Proyecto

1. **Iniciar sesión en Google Cloud:**
```bash
gcloud auth login
```

2. **Crear un nuevo proyecto o seleccionar uno existente:**
```bash
# Crear nuevo proyecto
gcloud projects create proyecto-fontana --name="Proyecto Fontana"

# O seleccionar un proyecto existente
gcloud config set project TU-PROJECT-ID
```

3. **Habilitar APIs necesarias:**
```bash
gcloud services enable cloudbuild.googleapis.com
gcloud services enable run.googleapis.com
```

### Paso 3: Desplegar en Cloud Run

1. **Navegar al directorio del proyecto:**
```bash
cd proyecto_fontana_app
```

2. **Desplegar usando gcloud:**
```bash
gcloud run deploy proyecto-fontana \
  --source . \
  --platform managed \
  --region us-central1 \
  --allow-unauthenticated
```

3. **Esperar a que termine el despliegue** (puede tardar 2-3 minutos)

4. **Acceder a tu aplicación** en la URL que se muestra al finalizar:
```
https://proyecto-fontana-XXXXX-uc.a.run.app
```

---

## 🌍 Despliegue en Firebase Hosting (Alternativa más simple)

Firebase es más sencillo para aplicaciones estáticas como esta:

### Paso 1: Instalar Firebase CLI
```bash
npm install -g firebase-tools
```

### Paso 2: Inicializar Firebase
```bash
# Iniciar sesión
firebase login

# Inicializar el proyecto
firebase init hosting
```

Cuando pregunte:
- **What do you want to use as your public directory?** → Presionar Enter (usar directorio actual)
- **Configure as a single-page app?** → Y (Yes)
- **Set up automatic builds with GitHub?** → N (No)

### Paso 3: Desplegar
```bash
firebase deploy
```

Tu aplicación estará disponible en:
```
https://tu-proyecto.web.app
```

---

## 📱 Despliegue en Netlify (La opción MÁS FÁCIL)

### Opción A: Drag & Drop
1. Ir a https://www.netlify.com
2. Registrarse o iniciar sesión
3. Arrastrar la carpeta del proyecto a la zona de "Drop"
4. ¡Listo! Tu sitio estará online en segundos

### Opción B: Con Netlify CLI
```bash
# Instalar Netlify CLI
npm install -g netlify-cli

# Iniciar sesión
netlify login

# Desplegar
netlify deploy --prod
```

---

## 📱 Despliegue en Vercel (Muy Rápido)

1. Ir a https://vercel.com
2. Registrarse con GitHub, GitLab o Bitbucket
3. Clic en "Add New..." → "Project"
4. Importar el proyecto (arrastrar carpeta o conectar repositorio)
5. Clic en "Deploy"

Tu sitio estará online en menos de 1 minuto.

---

## 🔧 Configuración de la Aplicación

### Datos Iniciales
La aplicación viene pre-cargada con las actividades principales del proyecto. Los datos se almacenan en el navegador del usuario (LocalStorage).

### Personalización
Para modificar los datos iniciales, editar el archivo `index.html` en la sección del array `activities` (aproximadamente línea 500).

### Backup de Datos
**Importante:** Los datos se guardan localmente en el navegador. Para hacer backup:
1. Usar el botón "📥 Exportar CSV" dentro de la aplicación
2. Guardar el archivo CSV generado
3. Importar nuevamente cuando sea necesario

---

## 📖 Uso de la Aplicación

### Funcionalidades Principales

1. **Agregar Nueva Actividad**
   - Clic en el botón verde "➕ Nueva Actividad"
   - Completar el formulario
   - Guardar

2. **Editar Actividad**
   - Clic en el botón amarillo ✏️ de la actividad
   - Modificar los campos necesarios
   - Guardar cambios

3. **Eliminar Actividad**
   - Clic en el botón rojo 🗑️ de la actividad
   - Confirmar eliminación

4. **Buscar y Filtrar**
   - Usar la caja de búsqueda para encontrar actividades
   - Usar los botones de filtro por estado

5. **Exportar Datos**
   - Clic en "📥 Exportar CSV"
   - El archivo se descargará automáticamente

### Campos de Actividad

- **Número:** Identificador de la actividad (ej: 1.1, 2.3)
- **Actividad:** Descripción detallada
- **Empresa/Proveedor:** Proveedor asignado
- **Responsable:** Persona a cargo
- **Estado:** Falta / En proceso / Realizado
- **Progreso:** Porcentaje de avance (0-100%)
- **Costo:** Monto en pesos argentinos
- **Fecha Inicio:** Fecha de inicio planificada
- **Fecha Fin:** Fecha de finalización planificada
- **Observaciones:** Notas adicionales

---

## 🔐 Seguridad y Privacidad

- **Datos Locales:** Todos los datos se almacenan en el navegador del usuario (no en un servidor)
- **Sin Base de Datos Externa:** No requiere configuración de base de datos
- **Offline:** Funciona completamente sin conexión a internet después de cargar
- **Sin Autenticación:** Versión básica sin sistema de usuarios (cualquiera con acceso al link puede ver y editar)

### Recomendaciones para Producción

Si querés restringir el acceso:

1. **Con Firebase:**
   - Activar Firebase Authentication
   - Configurar reglas de seguridad

2. **Con Google Cloud:**
   - Configurar Identity-Aware Proxy (IAP)
   - Restringir acceso por email

3. **Con Netlify:**
   - Usar Netlify Identity
   - Password protection para el sitio

---

## 📊 Estructura del Proyecto

```
proyecto_fontana_app/
│
├── index.html              # Aplicación principal
├── README.md              # Este archivo
├── MANUAL_PROYECTO.md     # Manual completo del proyecto
├── Dockerfile             # Para despliegue en contenedor
├── .dockerignore          # Archivos a ignorar en Docker
├── app.yaml               # Configuración para Google App Engine
├── package.json           # Metadatos del proyecto
└── documentos/            # Documentación adicional
    ├── plano_catastral.pdf
    └── fotos/             # Fotos del relevamiento
```

---

## 🆘 Solución de Problemas

### La aplicación no carga
- Verificar que todos los archivos estén en el mismo directorio
- Abrir la consola del navegador (F12) para ver errores
- Probar en otro navegador (Chrome, Firefox, Edge)

### Los datos no se guardan
- Verificar que las cookies/localStorage estén habilitados en el navegador
- No usar modo incógnito/privado
- Limpiar caché del navegador y recargar

### No puedo exportar CSV
- Verificar permisos de descarga del navegador
- Intentar con otro navegador
- Verificar que no haya bloqueadores de pop-ups

### El despliegue en la nube falla
- Verificar que estés logueado: `gcloud auth list`
- Verificar el proyecto activo: `gcloud config get-value project`
- Verificar que las APIs estén habilitadas
- Revisar los logs: `gcloud run services logs read proyecto-fontana`

---

## 🔄 Actualizaciones

Para actualizar la aplicación desplegada:

**Google Cloud Run:**
```bash
gcloud run deploy proyecto-fontana --source .
```

**Firebase:**
```bash
firebase deploy
```

**Netlify:**
```bash
netlify deploy --prod
```

**Vercel:**
```bash
vercel --prod
```

---

## 📞 Soporte

Para cualquier consulta o problema:
- Revisar este README
- Consultar el MANUAL_PROYECTO.md
- Revisar la consola del navegador (F12) en busca de errores

---

## 📄 Licencia

Este proyecto es de uso interno para el Proyecto Sucursal Fontana.

---

## ✨ Características Técnicas

- **HTML5 + CSS3 + JavaScript Vanilla**
- **Sin dependencias externas**
- **Responsive Design** (funciona en móviles)
- **LocalStorage** para persistencia
- **Exportación a CSV**
- **PWA-ready** (se puede instalar como app)

---

## 🎯 Próximos Pasos Recomendados

1. Desplegar la aplicación usando una de las opciones anteriores
2. Compartir el link con el equipo del proyecto
3. Comenzar a cargar y actualizar actividades
4. Hacer backups periódicos exportando a CSV
5. Revisar el progreso semanalmente

---

**¡Éxito con el Proyecto Fontana!** 🎉